from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

urlpatterns = [
    path("", views.post_list, name="post_list"),
    path("register/", views.register, name="register"),
    path("login/", views.CustomLoginView.as_view(), name="login"),
    path("logout/", LogoutView.as_view(next_page="post_list"), name="logout"),
    path("post/new/", views.post_create, name="post_create"),
    path("post/<int:post_id>/", views.post_detail, name="post_detail"),
    path("post/<int:post_id>/delete/", views.post_delete, name="post_delete"),  # Маршрут для удаления поста
    path("profile/", views.profile, name="profile"),
]
